package com.endrulis.evaluator.constants;

public class AppConstants {
    public static final String CONST_HUB_URL = "https://www.wix.com/_serverless/hiring-task-spreadsheet-evaluator";
    public static final String CONST_EMAIL = "endrulisr@gmail.com";
}
