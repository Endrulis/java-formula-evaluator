package com.endrulis.evaluator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EvaluatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
